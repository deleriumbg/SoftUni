﻿public enum TrafficLightColors
{
    Red,
    Green,
    Yellow
}
