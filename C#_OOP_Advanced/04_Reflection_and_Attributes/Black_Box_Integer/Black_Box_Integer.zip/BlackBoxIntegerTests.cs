﻿using System.Linq;
using System.Reflection;

namespace P02_BlackBoxInteger
{
    using System;

    public class BlackBoxIntegerTests
    {
        public static void Main()
        {
            Type classType = Type.GetType("P02_BlackBoxInteger.BlackBoxInteger");
            FieldInfo privateValue = classType.GetField("innerValue", BindingFlags.NonPublic | BindingFlags.Instance);
            MethodInfo[] classMethods = classType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);

            object instance = Activator.CreateInstance(classType, true);
            string input = Console.ReadLine();
            while (input != "END")
            {
                string[] inputArgs = input.Split('_');
                string command = inputArgs[0];
                int inputValue = int.Parse(inputArgs[1]);

                MethodInfo currentMethod = classMethods.First(x => x.Name == command);
                currentMethod.Invoke(instance, new object[] {inputValue});
                Console.WriteLine(privateValue.GetValue(instance));
                input = Console.ReadLine();
            }
        }
    }
}