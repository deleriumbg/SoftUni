﻿namespace Mordors_Cruel_Plan.Foods
{
    public class Unspecified : Food
    {
        private const int happiness = -1;

        public Unspecified() : base(happiness)
        {
        }
    }
}
