﻿namespace Mordors_Cruel_Plan.Foods
{
    public class HoneyCake : Food
    {
        private const int happiness = 5;

        public HoneyCake() : base(happiness)
        {
        }
    }
}
