﻿namespace Mordors_Cruel_Plan.Foods
{
    public class Apple : Food
    {
        private const int happiness = 1;

        public Apple() : base(happiness)
        {
        }
    }
}
