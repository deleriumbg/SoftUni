﻿namespace Mordors_Cruel_Plan.Foods
{
    public class Melon : Food
    {
        private const int happiness = 1;

        public Melon() : base(happiness)
        {
        }
    }
}
