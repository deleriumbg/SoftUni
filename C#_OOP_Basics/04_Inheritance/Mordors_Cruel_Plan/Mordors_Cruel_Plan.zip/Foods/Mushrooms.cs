﻿namespace Mordors_Cruel_Plan.Foods
{
    public class Mushrooms : Food
    {
        private const int happiness = -10;

        public Mushrooms() : base(happiness)
        {
        }
    }
}
