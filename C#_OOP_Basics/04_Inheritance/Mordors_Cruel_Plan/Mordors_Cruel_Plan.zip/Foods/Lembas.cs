﻿namespace Mordors_Cruel_Plan.Foods
{
    public class Lembas : Food
    {
        private const int happiness = 3;

        public Lembas() : base(happiness)
        {
        }
    }
}
