﻿namespace Mordors_Cruel_Plan.Moods
{
    public class Mood
    {
        public virtual string Type => "Mood";
    }
}
