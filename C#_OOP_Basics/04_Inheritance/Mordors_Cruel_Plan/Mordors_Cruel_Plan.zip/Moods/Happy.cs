﻿namespace Mordors_Cruel_Plan.Moods
{
    public class Happy : Mood
    {
        public override string Type => "Happy";
    }
}
