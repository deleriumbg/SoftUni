﻿namespace Mordors_Cruel_Plan.Moods
{
    public class Angry : Mood
    {
        public override string Type => "Angry";
    }
}
