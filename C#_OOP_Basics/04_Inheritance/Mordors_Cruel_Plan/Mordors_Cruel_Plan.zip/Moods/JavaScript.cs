﻿namespace Mordors_Cruel_Plan.Moods
{
    public class JavaScript : Mood
    {
        public override string Type => "JavaScript";
    }
}
