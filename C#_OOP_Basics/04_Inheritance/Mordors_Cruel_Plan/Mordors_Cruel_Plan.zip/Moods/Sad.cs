﻿namespace Mordors_Cruel_Plan.Moods
{
    public class Sad : Mood
    {
        public override string Type => "Sad";
    }
}
