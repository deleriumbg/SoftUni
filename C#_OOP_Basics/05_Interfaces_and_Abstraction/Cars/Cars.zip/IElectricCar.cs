﻿public interface IElectricCar : ICar
{
    int BatteryCount { get; }
}
