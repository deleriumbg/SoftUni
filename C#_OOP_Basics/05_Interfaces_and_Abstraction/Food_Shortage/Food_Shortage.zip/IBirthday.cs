﻿public interface IBirthday
{
    string Birthday { get; }
}
