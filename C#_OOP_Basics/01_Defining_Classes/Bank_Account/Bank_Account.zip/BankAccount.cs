﻿public class BankAccount
{
    private int id;
    private decimal balance;

    public int Id { get => id; set => id = value; }
    public decimal Balance { get => balance; set => balance = value; }

}