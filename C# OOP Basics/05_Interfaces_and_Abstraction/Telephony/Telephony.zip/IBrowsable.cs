﻿public interface IBrowsable
{
    string Browse(string website);
}
