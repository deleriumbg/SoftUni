﻿public interface IDriveable
{
    string UseBrakes();
    string PushTheGas();
}
