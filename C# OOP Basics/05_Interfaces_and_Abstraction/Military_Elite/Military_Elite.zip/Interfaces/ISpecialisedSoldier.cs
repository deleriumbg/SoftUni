﻿using System.Collections.Generic;

public interface ISpecialisedSoldier : IPrivate
{
    Corps Corps { get; }
}
