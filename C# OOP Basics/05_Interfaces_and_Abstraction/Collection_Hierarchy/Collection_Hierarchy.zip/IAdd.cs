﻿interface IAdd
{
    int Add(string element);
}
