﻿interface IRemove
{
    string Remove();
}
