﻿interface ICountable
{
    int Used { get; }
}
