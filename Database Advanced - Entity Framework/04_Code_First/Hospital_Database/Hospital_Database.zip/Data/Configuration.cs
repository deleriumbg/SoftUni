﻿namespace P01_HospitalDatabase.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DELIRIUM\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
