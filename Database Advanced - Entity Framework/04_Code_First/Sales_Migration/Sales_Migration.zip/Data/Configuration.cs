﻿namespace P03_SalesDatabase.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DELIRIUM\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
