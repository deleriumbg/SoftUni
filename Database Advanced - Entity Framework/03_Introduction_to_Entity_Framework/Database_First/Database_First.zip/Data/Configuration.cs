﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server= DELIRIUM\\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}
