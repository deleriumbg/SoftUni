﻿namespace P01_StudentSystem.Data 
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DELIRIUM\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
