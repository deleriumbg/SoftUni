﻿namespace P03_FootballBetting.Data.Models
{
    public enum PredictionEnum
    {
        HomeTeamWin,
        AwayTeamWin,
        Draw
    }
}
