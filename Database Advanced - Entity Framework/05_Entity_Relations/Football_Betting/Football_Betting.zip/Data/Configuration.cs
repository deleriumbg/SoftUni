﻿namespace P03_FootballBetting.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DELIRIUM\SQLEXPRESS;Database=FootballBetting;Integrated Security=True";
    }
}
