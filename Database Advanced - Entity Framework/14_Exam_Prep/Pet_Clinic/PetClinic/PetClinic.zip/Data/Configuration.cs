﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DELIRIUM\SQLEXPRESS;Database=PetClinic;Trusted_Connection=True";
    }
}
