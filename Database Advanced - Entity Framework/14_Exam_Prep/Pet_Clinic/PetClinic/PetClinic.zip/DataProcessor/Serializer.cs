﻿namespace PetClinic.DataProcessor
{
    using System;

    using PetClinic.Data;

    public class Serializer
    {
        public static string ExportAnimalsByOwnerPhoneNumber(PetClinicContext context, string phoneNumber)
        {
            throw new NotImplementedException();
        }

        public static string ExportAllProcedures(PetClinicContext context)
        {
            throw new NotImplementedException();
        }
    }
}
